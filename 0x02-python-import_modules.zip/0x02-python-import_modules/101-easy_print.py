#!/usr/bin/python3
import printing_easy
